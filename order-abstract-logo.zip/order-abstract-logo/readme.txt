page of order abstrict logo 

what is bogs? => cant to validation phone numbr length to max and min 11 and other inputs.

header and footer are has been error, because folder is not on cpannel our server